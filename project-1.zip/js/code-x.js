jQuery(document).ready(function ($) {
  /* ========= Active Buttons ========= */
  var url = document.location.href;
  $.each($(".header-menu a,footer-menu a"), function () {
    if (this.href == url) {
      $(this).addClass("active");
    }
  });
});

/* ========= to Top button  ========= */

$(window).scroll(function () {
  if ($(this).scrollTop() !== 0) $("#toTop").fadeIn();
  else $("#toTop").fadeOut();
});
$("#toTop").click(function () {
  $("body,html").animate({ scrollTop: 0 }, 500);
});

/* ========= Slow scrolling ========= */
$('a[href*="#"]').on("click", function () {
  $("html, body").animate(
    {
      scrollTop: $($.attr(this, "href")).offset().top - 100,
    },
    1500
  );
  return false;
});

/* ========= Burger Menu ========= */
$(function () {
  $(".burger").click(function () {
    $(".header-menu,.header-menu_block").toggleClass("active");
    $("body").toggleClass("lock");
  });
});

$(".header-menu a,.anchor-menu__hiden a").on("click", function () {
  $(".header-menu,.header-menu_block").toggleClass("active");
});

/* ========= Show More ========= */
$(document).ready(function () {
  $(".foto-portfolio__btn").click(function () {
    $(".foto-portfolio__btn").toggleClass("active");
    if ($(this).hasClass("active")) {
      $(this).html("Скрыть");
    } else {
      $(this).html("Показать ещё");
    }
    $(".foto-portfolio__sub-list").toggleClass("active");
  });
});

$(document).ready(function ($) {
  if ($("ul.foto-portfolio__list").find("li.foto-portfolio__item").length > 5) {
    $("a.foto-portfolio__btn").click(function () {
      $(
        "ul.foto-portfolio__list li.foto-portfolio__item:nth-child(n+6)"
      ).slideToggle("open");
      $(this).toggleClass("opnd_g");
      if ($(this).hasClass("opnd_g")) {
        $(this).html("Скрыть");
      } else {
        $(this).html("Смотреть все");
      }
    });
  } else {
    $("a.foto-portfolio__btn").hide();
  }
});

/* ========= Tabs ========= */

// Show the first tab and hide the rest
$(".tabs-wrapper").each(function () {
  let ths = $(this);
  ths.find(".tab-panel").not(":first").hide();
  ths
    .find(".tab")
    .click(function () {
      ths
        .find(".tab")
        .removeClass("active")
        .eq($(this).index())
        .addClass("active");
      ths
        .find(".tab-panel")
        .removeClass("active")
        .eq($(this).index())
        .addClass("active")
        .fadeIn();
    })
    .eq(0)
    .addClass("active");
});

/* ========= Slider  ========= */

$(document).ready(function () {
  $(".work-slider").slick({
    infinite: true,
    speed: 900,
    slidesToShow: 1,
    slidesToScroll: 1,
    // centerMode: true,
    // variableWidth: true,
    responsive: [
      {
        breakpoint: 1280,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1152,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 425,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  });
});

/* ========= Particles.js  ========= */
// particlesJS
var $particles_js = $("particles-js"),
  $particles_color = "#2b56f5",
  $particles_color_alt = "#00c0fa";
if ($particles_js.length > 0) {
  particlesJS(
    "particles-js",
    // Update your personal code.
    {
      particles: {
        number: {
          value: 30,
          density: {
            enable: true,
            value_area: 800,
          },
        },
        color: {
          value: $particles_color_alt,
        },
        shape: {
          type: "circle",
          opacity: 0.2,
          stroke: {
            width: 0,
            color: $particles_color,
          },
          polygon: {
            nb_sides: 5,
          },
          image: {
            src: "img/github.svg",
            width: 100,
            height: 100,
          },
        },
        opacity: {
          value: 0.3,
          random: false,
          anim: {
            enable: false,
            speed: 1,
            opacity_min: 0.12,
            sync: false,
          },
        },
        size: {
          value: 6,
          random: true,
          anim: {
            enable: false,
            speed: 40,
            size_min: 0.08,
            sync: false,
          },
        },
        line_linked: {
          enable: true,
          distance: 150,
          color: $particles_color,
          opacity: 0.5,
          width: 1.3,
        },
        move: {
          enable: true,
          speed: 6,
          direction: "none",
          random: false,
          straight: false,
          out_mode: "out",
          bounce: false,
          attract: {
            enable: false,
            rotateX: 600,
            rotateY: 1200,
          },
        },
      },
      interactivity: {
        detect_on: "canvas",
        events: {
          onhover: {
            enable: true,
            mode: "repulse",
          },
          onclick: {
            enable: true,
            mode: "push",
          },
          resize: true,
        },
        modes: {
          grab: {
            distance: 400,
            line_linked: {
              opacity: 1,
            },
          },
          bubble: {
            distance: 400,
            size: 40,
            duration: 2,
            opacity: 8,
            speed: 3,
          },
          repulse: {
            distance: 200,
            duration: 0.4,
          },
          push: {
            particles_nb: 4,
          },
          remove: {
            particles_nb: 2,
          },
        },
      },
      retina_detect: true,
    }
    // Stop here.
  );
}
